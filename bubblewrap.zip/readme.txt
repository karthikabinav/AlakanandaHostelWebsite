INSTRUCTIONS

NOTE: you do not have permission to alter the .swf file in any way. You may redistribute it so long as it is accompanied by this readme.txt file. You may not charge money for it. Permission to use virtual bubblewrap on your site is limited to the official distribution version(s) only.

To put the bubblewrap on your site, move the virtual-bubblewrap-distv1.1.swf file to the directory your page is in, and paste this code into your page:



<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="487" height="300" id="bubblewrap">
    <param name=movie value="virtual-bubblewrap-distv1.1.swf">
    <param name=loop value=false>
    <param name=menu value=false>
    <param name=quality value=high>
    <param name=bgcolor value=#FFFFFF>
    <embed src="virtual-bubblewrap-distv1.1.swf" loop=false menu=false quality=high bgcolor=#FFFFFF  width="487" height="300" 
 type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">
    </embed> 
  </object>
<p><i>Virtual Bubblewrap &copy; <a href="http://www.virtual-bubblewrap.com/">www.virtual-bubblewrap.com</a></i><br><font color="#FFFFFF">virtual-bubblewrap-distv1.1</font></p>